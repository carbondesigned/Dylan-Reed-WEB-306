<?php
require_once("config.php");
require_once("Database.php");
require_once("Media.php");
require_once("Music.php");
require_once("Movie.php");
