<?php

date_default_timezone_set("America/Toronto");

define('DB_USER', 'dreed');
define('DB_PASSWORD', 'qh6xhqh6xh2mtqj2mtqj');
define('DB_HOST', 'localhost');
define('DB_NAME', 'dreeddb');


$config_blogname = "WEB306 Dylan Reed Blog";
$config_author = "Dylan Reed";
