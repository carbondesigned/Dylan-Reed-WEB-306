<?php

class Entry
{
}
