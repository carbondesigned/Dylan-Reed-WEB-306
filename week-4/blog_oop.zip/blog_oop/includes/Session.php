<?php

class Session
{
}
