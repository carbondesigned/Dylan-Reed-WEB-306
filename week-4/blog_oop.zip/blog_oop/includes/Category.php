<?php

class Category
{
}
