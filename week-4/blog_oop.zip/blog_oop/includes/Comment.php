<?php

class Comment
{
}
