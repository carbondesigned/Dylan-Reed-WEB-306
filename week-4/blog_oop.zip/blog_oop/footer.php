</div>

<div id="footer">
	<p>&copy; <?php echo $config_author; ?></p>
</div>
</body>
</html>
<?php mysqli_close($db); ?>