<?php
define('DB_USER', 'dreed');
define('DB_PASSWORD', 'qh6xhqh6xh2mtqj2mtqj');
define('DB_HOST', 'localhost');
define('DB_NAME', 'dreeddb');
?>