<?php

class BankAccount {

	public $type;
	public $number;
	public $name;
	public $balance;
	
	public function deposit() {
	}
	
	public function withdrawal() {
	}
	
	public function accountQuery() {
	}
	
	public function setName() {
	}

}

$johnsSavingsAccount = new BankAccount();

?>